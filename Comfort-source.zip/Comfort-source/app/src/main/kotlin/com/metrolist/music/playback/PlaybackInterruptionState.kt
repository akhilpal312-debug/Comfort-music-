package com.metrolist.music.playback

/** Resume only an interrupted local item, never a manual pause or a replacement queue. */
class PlaybackInterruptionState {
    private var interruptedId: String? = null
    val shouldResume: Boolean get() = interruptedId != null
    fun interrupted(wasPlaying: Boolean, mediaId: String?) {
        if (wasPlaying && !mediaId.isNullOrBlank() && interruptedId == null) interruptedId = mediaId
    }
    fun canResume(mediaId: String?): Boolean = interruptedId != null && interruptedId == mediaId
    fun cancel() { interruptedId = null }
}
