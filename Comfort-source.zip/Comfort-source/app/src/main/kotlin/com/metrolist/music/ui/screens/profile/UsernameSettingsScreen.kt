package com.metrolist.music.ui.screens.profile

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.metrolist.music.LocalPlayerAwareWindowInsets
import com.metrolist.music.R
import com.metrolist.music.profile.UsernameStore
import com.metrolist.music.ui.icons.ComfortIcons
import com.metrolist.music.ui.icons.ComfortIcon as Icon
import com.metrolist.music.ui.typography.ComfortText as Text
import com.metrolist.music.ui.typography.ComfortTextStyles
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UsernameSettingsScreen(navController: NavController, onOpenAccounts: () -> Unit) {
    val context = LocalContext.current
    val store = remember { UsernameStore.get(context) }
    val registry by store.state.collectAsStateWithLifecycle()
    val profile = registry.active
    val scope = rememberCoroutineScope()
    var name by rememberSaveable(profile.id) { mutableStateOf(profile.displayName) }
    var error by remember { mutableStateOf<String?>(null) }
    var saving by remember { mutableStateOf(false) }
    var saved by remember { mutableStateOf(false) }
    var newProfile by remember { mutableStateOf(false) }
    var newName by remember { mutableStateOf("") }
    var switchTarget by remember { mutableStateOf<String?>(null) }
    var discardForCreate by remember { mutableStateOf(false) }
    val defaultHeading = stringResource(R.string.comfort_default_heading)
    val savedLabel = stringResource(R.string.comfort_username_saved)
    fun switch(id: String) { scope.launch { try { withContext(Dispatchers.IO) { store.switchTo(id) }; error = null; saved = false } catch (_: Exception) { error = "Username could not be switched." } } }
    Scaffold(contentWindowInsets = LocalPlayerAwareWindowInsets.current,
        topBar = { TopAppBar(title = { Text(stringResource(R.string.comfort_personal_profile)) }, navigationIcon = { IconButton(onClick = { navController.navigateUp() }) { Icon(painterResource(ComfortIcons.ArrowBack), stringResource(R.string.back)) } }) },
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Text(name.ifBlank { defaultHeading }, style = MaterialTheme.typography.headlineSmall)
            OutlinedTextField(name, { name = it; saved = false }, label = { Text(stringResource(R.string.comfort_display_name)) },
                enabled = !saving, singleLine = true, textStyle = ComfortTextStyles.Input, modifier = Modifier.fillMaxWidth(),
                supportingText = { Text(stringResource(R.string.comfort_username_hint)) })
            TextButton(onClick = { name = ""; saved = false }, enabled = !saving) { Text(stringResource(R.string.comfort_use_default_heading)) }
            Button(onClick = {
                val draft = name
                scope.launch {
                    saving = true; error = null
                    try {
                        withContext(Dispatchers.IO) { store.save(profile.id, draft) }
                        name = store.state.value.profiles.first { it.id == profile.id }.displayName; saved = true
                    } catch (e: IllegalArgumentException) { error = e.message ?: "Check the display name." }
                    catch (_: Exception) { error = "The name could not be saved. Your previous saved name is unchanged." }
                    finally { saving = false }
                }
            }, enabled = !saving, modifier = Modifier.fillMaxWidth()) { Text(stringResource(if (saving) R.string.comfort_username_saving else R.string.comfort_save_username)) }
            if (saved) Text(savedLabel, color = MaterialTheme.colorScheme.primary)
            error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            store.recoveryWarning?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            Text(stringResource(R.string.comfort_local_usernames), style = MaterialTheme.typography.titleLarge)
            Text(stringResource(R.string.comfort_local_usernames_hint), style = MaterialTheme.typography.bodyMedium)
            registry.profiles.forEach { other ->
                OutlinedButton(onClick = { if (other.id != profile.id) { if (name != profile.displayName) switchTarget = other.id else switch(other.id) } }, enabled = !saving, modifier = Modifier.fillMaxWidth()) {
                    Text(other.heading(defaultHeading) + if (other.id == profile.id) " · current" else "")
                }
            }
            OutlinedButton(onClick = { if (name != profile.displayName) discardForCreate = true else { newName = ""; newProfile = true } }, enabled = !saving) { Text(stringResource(R.string.comfort_create_local_username)) }
            HorizontalDivider()
            Text(stringResource(R.string.comfort_connected_accounts), style = MaterialTheme.typography.titleLarge)
            Text(stringResource(R.string.comfort_accounts_hint), style = MaterialTheme.typography.bodyMedium)
            Button(onClick = onOpenAccounts, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.comfort_manage_accounts)) }
            TextButton(onClick = { navController.navigate("settings/integrations") }, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.comfort_other_accounts)) }
        }
    }
    if (newProfile) AlertDialog(onDismissRequest = { newProfile = false }, title = { Text(stringResource(R.string.comfort_create_local_username)) }, text = { OutlinedTextField(newName, { newName = it }, label = { Text(stringResource(R.string.comfort_display_name)) }, singleLine = true, textStyle = ComfortTextStyles.Input) }, confirmButton = { TextButton(onClick = {
        val draft = newName
        scope.launch { try { withContext(Dispatchers.IO) { store.create(draft) }; newProfile = false; saved = false; error = null } catch (e: Exception) { error = e.message ?: "The local username could not be created."; newProfile = false } }
    }) { Text("Create") } }, dismissButton = { TextButton(onClick = { newProfile = false }) { Text("Cancel") } })
    if (switchTarget != null || discardForCreate) AlertDialog(onDismissRequest = { switchTarget = null; discardForCreate = false }, title = { Text("Discard unsaved name?") }, text = { Text("Save first if you want to keep your edits.") }, confirmButton = { TextButton(onClick = {
        val target = switchTarget; switchTarget = null
        if (discardForCreate) { discardForCreate = false; newName = ""; newProfile = true } else target?.let { switch(it) }
    }) { Text("Discard and continue") } }, dismissButton = { TextButton(onClick = { switchTarget = null; discardForCreate = false }) { Text("Keep editing") } })
}
