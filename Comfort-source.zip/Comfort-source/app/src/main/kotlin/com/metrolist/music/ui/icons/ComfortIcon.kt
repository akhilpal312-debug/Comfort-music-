package com.metrolist.music.ui.icons

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.annotation.DrawableRes
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.material3.Icon as MaterialIcon

/** Grid/stroke tokens also used by the SVG → VectorDrawable generator. */
object ComfortIconTokens {
    val Small = 18.dp
    val Medium = 24.dp
    val Large = 32.dp
    val Badge = 16.dp
    val TouchTarget = 48.dp
    val ContainerShape = CircleShape
    const val StandardStroke = 2f
    const val EmphasizedStroke = 2.25f
    const val DisabledAlpha = 0.38f
    const val SelectionDurationMillis = 160

    @Composable
    fun defaultColor(): Color = MaterialTheme.colorScheme.onSurface

    @Composable
    fun mutedColor(): Color = MaterialTheme.colorScheme.onSurfaceVariant

    @Composable
    fun activeColor(): Color = MaterialTheme.colorScheme.primary

    @Composable
    fun selectedColor(): Color = activeColor()

    @Composable
    fun disabledColor(): Color = defaultColor().copy(alpha = DisabledAlpha)

    @Composable
    fun resolve(tint: Color): Color {
        if (tint == Color.Unspecified) return tint
        val scheme = MaterialTheme.colorScheme
        // Keep contrast/on-container roles and semantic error/warning colors intact.
        val opaque = tint.copy(alpha = 1f)
        val mapped = when (opaque) {
            scheme.primary.copy(alpha = 1f), scheme.secondary.copy(alpha = 1f) -> activeColor()
            scheme.onSurface.copy(alpha = 1f), scheme.onBackground.copy(alpha = 1f) -> defaultColor()
            scheme.onSurfaceVariant.copy(alpha = 1f) -> mutedColor()
            else -> opaque
        }
        return mapped.copy(alpha = tint.alpha)
    }
}

/** Drop-in Material Icon: no click handling, navigation, or semantics interception. */
@Composable
fun ComfortIcon(
    painter: Painter,
    contentDescription: String?,
    modifier: Modifier = Modifier,
    tint: Color = LocalContentColor.current,
) {
    MaterialIcon(painter, contentDescription, modifier, ComfortIconTokens.resolve(tint))
}

@Composable
fun ComfortIcon(
    imageVector: ImageVector,
    contentDescription: String?,
    modifier: Modifier = Modifier,
    tint: Color = LocalContentColor.current,
) {
    MaterialIcon(imageVector, contentDescription, modifier, ComfortIconTokens.resolve(tint))
}

@Composable
fun ComfortIcon(
    bitmap: ImageBitmap,
    contentDescription: String?,
    modifier: Modifier = Modifier,
    tint: Color = LocalContentColor.current,
) {
    MaterialIcon(bitmap, contentDescription, modifier, ComfortIconTokens.resolve(tint))
}

/** Opt-in transition: static controls don't acquire unnecessary animation. */
@Composable
fun comfortIconStateColor(selected: Boolean, enabled: Boolean = true): Color {
    val target = when {
        !enabled -> ComfortIconTokens.disabledColor()
        selected -> ComfortIconTokens.selectedColor()
        else -> ComfortIconTokens.mutedColor()
    }
    val color by animateColorAsState(
        targetValue = target,
        animationSpec = tween(ComfortIconTokens.SelectionDurationMillis),
        label = "Comfort icon selection",
    )
    return color
}

/** Tint only the icon placeholder, never a successfully loaded photo or album cover. */
@Composable
fun comfortIconPainter(
    @DrawableRes id: Int,
    color: Color = ComfortIconTokens.defaultColor(),
): Painter {
    val source = painterResource(id)
    val resolvedColor = ComfortIconTokens.resolve(color)
    return remember(source, resolvedColor) {
        object : Painter() {
            override val intrinsicSize = source.intrinsicSize
            override fun DrawScope.onDraw() {
                val drawSize = size
                with(source) {
                    draw(size = drawSize, colorFilter = ColorFilter.tint(resolvedColor))
                }
            }
        }
    }
}
