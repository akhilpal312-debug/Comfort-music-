package com.metrolist.music.ui.component

import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.metrolist.music.R

/** Fixed developer identity, deliberately unrelated to editable local usernames/accounts. */
@Composable
fun PermanentDeveloperPortrait(modifier: Modifier = Modifier) {
    Image(
        painter = painterResource(R.drawable.comfort_developer_portrait),
        contentDescription = stringResource(R.string.comfort_developer_portrait_description),
        contentScale = ContentScale.Crop,
        alignment = Alignment.TopCenter,
        modifier = modifier.size(112.dp).clip(CircleShape)
            .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.25f), CircleShape),
    )
}
