/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.ui.screens

import com.metrolist.music.ui.icons.ComfortIcons

import androidx.annotation.DrawableRes
import androidx.annotation.StringRes
import androidx.compose.runtime.Immutable
import com.metrolist.music.R

@Immutable
sealed class Screens(
    @StringRes val titleId: Int,
    @DrawableRes val iconIdInactive: Int,
    @DrawableRes val iconIdActive: Int,
    val route: String,
) {
    object Home : Screens(
        titleId = R.string.home,
        iconIdInactive = ComfortIcons.HomeOutlined,
        iconIdActive = ComfortIcons.HomeFilled,
        route = "home"
    )

    object Search : Screens(
        titleId = R.string.search,
        iconIdInactive = ComfortIcons.Search,
        iconIdActive = ComfortIcons.Search,
        route = "search_input"
    )

    object ListenTogether : Screens(
        titleId = R.string.together,
        iconIdInactive = ComfortIcons.GroupOutlined,
        iconIdActive = ComfortIcons.GroupFilled,
        route = "listen_together"
    )

    object Library : Screens(
        titleId = R.string.filter_library,
        iconIdInactive = ComfortIcons.LibraryMusicOutlined,
        iconIdActive = ComfortIcons.LibraryMusicFilled,
        route = "library"
    )

    companion object {
        val MainScreens = listOf(Home, Search, ListenTogether, Library)
    }
}
