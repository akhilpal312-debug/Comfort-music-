package com.metrolist.music.ui.theme

import com.metrolist.music.ui.typography.ComfortFontFamilies

val bbh_bartle = ComfortFontFamilies.Music
