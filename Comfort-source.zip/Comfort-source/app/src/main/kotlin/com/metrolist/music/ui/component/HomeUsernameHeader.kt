package com.metrolist.music.ui.component

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.metrolist.music.R
import com.metrolist.music.ui.typography.ComfortText

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeUsernameHeader(displayName: String, pureBlack: Boolean, onEdit: () -> Unit, modifier: Modifier = Modifier) {
    val editLabel = stringResource(R.string.comfort_edit_username)
    Surface(color = if (pureBlack) Color.Black else MaterialTheme.colorScheme.surface, modifier = modifier.fillMaxWidth()) {
        ComfortText(
            text = displayName.ifBlank { stringResource(R.string.comfort_default_heading) },
            style = MaterialTheme.typography.titleLarge,
            fontSize = 20.sp,
            softWrap = true,
            maxLines = Int.MAX_VALUE,
            overflow = TextOverflow.Visible,
            modifier = Modifier.fillMaxWidth().windowInsetsPadding(TopAppBarDefaults.windowInsets)
                .clickable(role = Role.Button, onClickLabel = editLabel, onClick = onEdit)
                .padding(horizontal = 16.dp, vertical = 14.dp),
        )
    }
}
