package com.metrolist.music.auth

import com.metrolist.innertube.utils.parseCookieString
import kotlinx.serialization.json.*
import java.net.URI

object YouTubeWebSession {
    fun isMusicOrigin(url: String?): Boolean = runCatching {
        val u = URI(url ?: "")
        u.scheme == "https" && u.host == "music.youtube.com" && u.port in listOf(-1, 443)
    }.getOrDefault(false)

    fun hasAuthCookie(cookie: String): Boolean = runCatching {
        val values = parseCookieString(cookie)
        listOf("SAPISID", "__Secure-3PAPISID", "__Secure-1PAPISID").any { !values[it].isNullOrBlank() }
    }.getOrDefault(false)

    fun decodeJavascriptResult(raw: String?): JsonObject? = runCatching {
        if (raw == null || raw == "null") return null
        val result = Json.parseToJsonElement(raw)
        if (result is JsonObject) result else Json.parseToJsonElement(result.jsonPrimitive.content).jsonObject
    }.getOrNull()

    const val SCRIPT = """(function(){var c=(window.ytcfg&&window.ytcfg.data_)||(window.yt&&window.yt.config_)||{};return JSON.stringify({visitorData:c.VISITOR_DATA||null,dataSyncId:c.DATASYNC_ID||'',authUser:String(c.SESSION_INDEX||0),loggedIn:c.LOGGED_IN===true});})()"""
}
