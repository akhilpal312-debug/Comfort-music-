package com.metrolist.music.ui.typography

import android.content.Context
import android.graphics.Typeface
import androidx.core.content.res.ResourcesCompat
import com.metrolist.music.R

/** Native Canvas exports/glow use the same bundled family, with shaped-script fallbacks. */
object ComfortTypefaces {
    fun brand(context: Context): Typeface = ResourcesCompat.getFont(context, R.font.comfort_brand_fraktur) ?: Typeface.DEFAULT_BOLD
    fun forText(context: Context, text: String, bold: Boolean = false): Typeface {
        val scripts = comfortScriptRuns(text).map { it.script }
        val font = when {
            ComfortScript.Devanagari in scripts -> if (bold) R.font.comfort_devanagari_700 else R.font.comfort_devanagari_400
            ComfortScript.Gurmukhi in scripts -> if (bold) R.font.comfort_gurmukhi_700 else R.font.comfort_gurmukhi_400
            ComfortScript.System in scripts -> return if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            else -> if (bold) R.font.comfort_music_italic_700 else R.font.comfort_music_italic_400
        }
        return ResourcesCompat.getFont(context, font) ?: Typeface.DEFAULT
    }
}
