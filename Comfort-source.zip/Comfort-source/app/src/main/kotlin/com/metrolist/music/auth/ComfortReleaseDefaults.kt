package com.metrolist.music.auth

import androidx.datastore.preferences.core.MutablePreferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import com.metrolist.music.constants.AudioFocusEnabledKey
import com.metrolist.music.constants.DynamicThemeKey

val ComfortArtworkAndFocusDefaultsKey = booleanPreferencesKey("comfortArtworkAndFocusDefaultsV1")
/** One-time upgrade setting requested for this build; subsequent user choices are respected. */
fun applyComfortReleaseDefaults(prefs: MutablePreferences) {
    if (prefs[ComfortArtworkAndFocusDefaultsKey] != true) {
        prefs[DynamicThemeKey] = true
        prefs[AudioFocusEnabledKey] = true
        prefs[ComfortArtworkAndFocusDefaultsKey] = true
    }
}
