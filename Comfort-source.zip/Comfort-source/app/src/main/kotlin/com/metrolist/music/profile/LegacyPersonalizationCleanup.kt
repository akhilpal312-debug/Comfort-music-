package com.metrolist.music.profile

import android.app.NotificationManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import com.metrolist.music.utils.dataStore
import java.io.File
import java.nio.file.Files

/** Upgrade-only cleanup; no capture, speech, image selection or service startup. */
object LegacyPersonalizationCleanup {
    suspend fun run(context: Context) {
        runCatching {
            context.stopService(Intent().setComponent(ComponentName(context.packageName, "com.metrolist.music.assistant.ComfortWakeService")))
            context.getSystemService(NotificationManager::class.java)?.apply {
                cancel(8024)
                deleteNotificationChannel("comfort_assistant_microphone")
            }
        }
        runCatching { UsernameStore.get(context) }
        runCatching {
            val dir = File(context.cacheDir, "comfort_profile_crop")
            if (!Files.isSymbolicLink(dir.toPath())) {
                dir.listFiles().orEmpty().filter {
                    it.isFile && it.name.matches(Regex("[a-f0-9-]{36}\\.jpg")) &&
                        it.canonicalFile.parentFile == dir.canonicalFile && !Files.isSymbolicLink(it.toPath())
                }.forEach { it.delete() }
                if (dir.listFiles()?.isEmpty() == true) dir.delete()
            }
        }
        runCatching { context.dataStore.edit { it.remove(stringPreferencesKey("discordAvatar")); it.remove(booleanPreferencesKey("showRecognizeButton")) } }
    }
}
