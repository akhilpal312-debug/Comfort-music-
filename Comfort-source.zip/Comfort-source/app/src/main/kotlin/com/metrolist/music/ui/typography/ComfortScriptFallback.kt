package com.metrolist.music.ui.typography

import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontSynthesis
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

enum class ComfortScript { Latin, Devanagari, Gurmukhi, System }
data class ComfortScriptRun(val start: Int, val end: Int, val script: ComfortScript)

/** UTF-16 offsets match AnnotatedString; joiners/marks stay with their shaping run. */
fun comfortScriptRuns(text: String): List<ComfortScriptRun> {
    if (text.isEmpty()) return emptyList()
    val result = mutableListOf<ComfortScriptRun>()
    var current = ComfortScript.Latin
    var start = 0
    var offset = 0
    while (offset < text.length) {
        val cp = Character.codePointAt(text, offset)
        val script = when (Character.UnicodeScript.of(cp)) {
            Character.UnicodeScript.DEVANAGARI -> ComfortScript.Devanagari
            Character.UnicodeScript.GURMUKHI -> ComfortScript.Gurmukhi
            Character.UnicodeScript.LATIN, Character.UnicodeScript.GREEK, Character.UnicodeScript.CYRILLIC -> ComfortScript.Latin
            Character.UnicodeScript.COMMON, Character.UnicodeScript.INHERITED -> current
            else -> ComfortScript.System
        }
        if (script != current) {
            if (offset > start) result += ComfortScriptRun(start, offset, current)
            start = offset
            current = script
        }
        offset += Character.charCount(cp)
    }
    if (offset > start) result += ComfortScriptRun(start, offset, current)
    return result
}

fun comfortAnnotatedText(text: AnnotatedString, brandName: Boolean = false): AnnotatedString {
    val builder = AnnotatedString.Builder(text)
    for (run in comfortScriptRuns(text.text)) {
        val family = when (run.script) {
            ComfortScript.Devanagari -> ComfortFontFamilies.Devanagari
            ComfortScript.Gurmukhi -> ComfortFontFamilies.Gurmukhi
            ComfortScript.System -> FontFamily.Default
            ComfortScript.Latin -> null
        }
        if (family != null) builder.addStyle(
            SpanStyle(fontFamily = family, fontStyle = FontStyle.Normal, fontSynthesis = FontSynthesis.None),
            run.start, run.end,
        )
    }
    if (brandName) {
        Regex("(?<![A-Za-z])Comfort(?![A-Za-z])").findAll(text.text).forEach { match ->
            builder.addStyle(
                SpanStyle(fontFamily = ComfortFontFamilies.Brand, fontStyle = FontStyle.Normal,
                    fontWeight = FontWeight.Bold, fontSynthesis = FontSynthesis.None, letterSpacing = 0.sp),
                match.range.first, match.range.last + 1,
            )
        }
    }
    return builder.toAnnotatedString()
}

fun comfortAnnotatedText(text: String, brandName: Boolean = false): AnnotatedString =
    comfortAnnotatedText(AnnotatedString(text), brandName)
