package com.metrolist.music.profile

import java.io.File
import java.io.FileOutputStream
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import java.util.UUID
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject

@Serializable
data class UsernameProfile(val id: String, val displayName: String = "") {
    fun heading(default: String): String = displayName.ifBlank { default }
}

@Serializable
data class UsernameRegistry(val activeId: String, val profiles: List<UsernameProfile>, val schemaVersion: Int = 2) {
    val active: UsernameProfile get() = profiles.first { it.id == activeId }
}

/** Stable local identities are retained; the stored model contains only IDs and names. */
class UsernameProfiles(private val root: File) {
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }
    private val file = File(root, "profiles.json")
    private var storageLocked = false
    var recoveryWarning: String? = null
        private set
    private val mutable = MutableStateFlow(load())
    val state = mutable.asStateFlow()

    private fun load(): UsernameRegistry {
        root.mkdirs()
        if (file.exists()) {
            val text = runCatching { require(file.length() < 512 * 1024); file.readText() }.getOrNull()
            val loaded = text?.let { runCatching {
                val value = json.decodeFromString<UsernameRegistry>(it)
                require(value.profiles.isNotEmpty() && value.profiles.size <= 20)
                require(value.profiles.map { p -> p.id }.distinct().size == value.profiles.size)
                value.profiles.forEach { p -> validateId(p.id); validateName(p.displayName) }
                require(value.profiles.any { p -> p.id == value.activeId })
                value.copy(schemaVersion = 2)
            }.getOrNull() }
            if (loaded != null) {
                // Rewrite legacy fields before removing only this feature's private files.
                val data = json.parseToJsonElement(text!!).jsonObject
                val legacy = data["schemaVersion"]?.toString() != "2" || data["profiles"]?.jsonArray?.any {
                    "photo" in it.jsonObject || "assistant" in it.jsonObject
                } == true
                if (legacy) {
                    if (runCatching { persist(loaded) }.isFailure) {
                        recoveryWarning = "Your saved names are loaded, but storage migration could not finish. Try saving again when storage is available."
                        return loaded
                    }
                }
                removeLegacyPrivateImages()
                return loaded
            }
            val recovery = File(root, "profiles.recovery-${UUID.randomUUID()}.json")
            if (!file.renameTo(recovery)) storageLocked = true
            recoveryWarning = "Previous username data could not be read and was preserved privately for recovery. Music data was not changed."
        }
        val default = UsernameProfile(UUID.randomUUID().toString())
        return UsernameRegistry(default.id, listOf(default)).also {
            if (!storageLocked && runCatching { persist(it) }.isSuccess) removeLegacyPrivateImages()
            else recoveryWarning = recoveryWarning ?: "Username storage is unavailable. You can still listen to music."
        }
    }

    private fun persist(registry: UsernameRegistry) {
        check(!storageLocked) { "Existing username data needs recovery before it can be replaced" }
        val temp = File(root, "profiles.pending")
        FileOutputStream(temp).use { it.write(json.encodeToString(registry).toByteArray()); it.fd.sync() }
        Files.move(temp.toPath(), file.toPath(), StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING)
    }

    private fun commit(registry: UsernameRegistry) {
        persist(registry)
        mutable.value = registry
        removeLegacyPrivateImages()
    }

    @Synchronized fun create(name: String): UsernameProfile {
        val value = validateName(name)
        require(state.value.profiles.size < 20) { "Up to 20 local usernames are supported" }
        val profile = UsernameProfile(UUID.randomUUID().toString(), value)
        commit(UsernameRegistry(profile.id, state.value.profiles + profile))
        return profile
    }

    @Synchronized fun switchTo(id: String) {
        validateId(id); require(state.value.profiles.any { it.id == id })
        commit(state.value.copy(activeId = id))
    }

    @Synchronized fun save(id: String, name: String) {
        validateId(id); require(state.value.profiles.any { it.id == id })
        val value = validateName(name)
        commit(state.value.copy(profiles = state.value.profiles.map { if (it.id == id) it.copy(displayName = value) else it }))
    }

    private fun removeLegacyPrivateImages() {
        root.listFiles().orEmpty().filter { it.isDirectory && validId(it.name) && !Files.isSymbolicLink(it.toPath()) }.forEach { dir ->
            dir.listFiles().orEmpty().filter {
                it.isFile && it.name.matches(Regex("[a-f0-9-]{36}\\.jpg")) &&
                    it.canonicalFile.parentFile == dir.canonicalFile && !Files.isSymbolicLink(it.toPath())
            }.forEach { runCatching { it.delete() } }
            if (dir.listFiles()?.isEmpty() == true) runCatching { dir.delete() }
        }
    }

    companion object {
        private fun validId(id: String): Boolean = runCatching { UUID.fromString(id).toString() == id }.getOrDefault(false)
        fun validateId(id: String) { require(validId(id)) { "Invalid local identity" } }
        fun validateName(name: String): String {
            val clean = name.trim()
            require(clean.codePointCount(0, clean.length) <= 80) { "Use up to 80 characters" }
            require(clean.none { Character.isISOControl(it) }) { "Use a single-line display name" }
            return clean
        }
    }
}
