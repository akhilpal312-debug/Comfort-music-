package com.metrolist.music.ui.component

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.Preferences
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.metrolist.music.R
import com.metrolist.music.constants.InnerTubeCookieKey
import com.metrolist.music.constants.SpotifySpDcKey
import com.metrolist.music.ui.typography.ComfortText as Text
import com.metrolist.music.utils.dataStore
import kotlinx.coroutines.launch

val ComfortWelcomeSeenKey = booleanPreferencesKey("comfortWelcomeSeen")
fun shouldOfferFirstLogin(prefs: Preferences): Boolean = prefs[ComfortWelcomeSeenKey] != true &&
    prefs[InnerTubeCookieKey].isNullOrBlank() && prefs[SpotifySpDcKey].isNullOrBlank()

@Composable
fun FirstOpenLoginPrompt(navController: NavController) {
    val context = LocalContext.current
    val prefs by context.dataStore.data.collectAsStateWithLifecycle(initialValue = null)
    val scope = rememberCoroutineScope()
    var saving by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf(false) }
    val p = prefs ?: return
    LaunchedEffect(p[ComfortWelcomeSeenKey], p[InnerTubeCookieKey], p[SpotifySpDcKey]) {
        if (p[ComfortWelcomeSeenKey] != true && !shouldOfferFirstLogin(p)) {
            runCatching { context.dataStore.edit { it[ComfortWelcomeSeenKey] = true } }
        }
    }
    if (!shouldOfferFirstLogin(p)) return
    fun choose(route: String?) {
        if (saving) return
        scope.launch {
            saving = true
            try {
                context.dataStore.edit { it[ComfortWelcomeSeenKey] = true }
                if (route != null) navController.navigate(route) { launchSingleTop = true }
            } catch (_: Exception) { error = true }
            finally { saving = false }
        }
    }
    LoginWelcomeDialog(saving, error, { choose("login") }, { choose("settings/spotify/login") }, { choose(null) })
}

@Composable
fun LoginWelcomeDialog(busy: Boolean, hasError: Boolean, onYouTube: () -> Unit, onSpotify: () -> Unit, onGuest: () -> Unit) {
    AlertDialog(onDismissRequest = { if (!busy) onGuest() },
        title = { Text(stringResource(R.string.comfort_welcome_title)) },
        text = { Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(stringResource(R.string.comfort_welcome_description))
            Button(onClick = onYouTube, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.comfort_connect_youtube)) }
            Button(onClick = onSpotify, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.comfort_connect_spotify)) }
            if (hasError) Text(stringResource(R.string.comfort_welcome_save_failed))
        } },
        confirmButton = { TextButton(onClick = onGuest, enabled = !busy) { Text(stringResource(R.string.comfort_continue_guest)) } })
}
