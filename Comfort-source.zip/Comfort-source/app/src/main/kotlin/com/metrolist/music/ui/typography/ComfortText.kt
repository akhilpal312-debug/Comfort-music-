package com.metrolist.music.ui.typography

import androidx.compose.foundation.text.InlineTextContent
import androidx.compose.material3.LocalTextStyle
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontSynthesis
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.TextUnitType
import androidx.compose.material3.Text as MaterialText

private fun resolvedStyle(style: TextStyle, fontSize: TextUnit, fontFamily: FontFamily?, fontStyle: FontStyle?): TextStyle {
    val size = if (fontSize != TextUnit.Unspecified) fontSize else style.fontSize
    val family = fontFamily ?: style.fontFamily ?: ComfortFontFamilies.Music
    val isSmall = size.type == TextUnitType.Sp && size.value < 13f
    val isBrand = family == ComfortFontFamilies.Brand
    val useReadable = isSmall && family == ComfortFontFamilies.Music
    return style.copy(
        fontFamily = if (useReadable) ComfortFontFamilies.Readable else family,
        fontStyle = when {
            isBrand || useReadable || family == ComfortFontFamilies.Readable -> FontStyle.Normal
            family == ComfortFontFamilies.Music -> FontStyle.Italic
            else -> fontStyle ?: style.fontStyle
        },
        fontSynthesis = FontSynthesis.None,
    )
}

/** Plain content/annotations/links/semantics stay intact; only font styling is added. */
@Composable
fun ComfortText(
    text: String,
    modifier: Modifier = Modifier,
    color: Color = Color.Unspecified,
    fontSize: TextUnit = TextUnit.Unspecified,
    fontStyle: FontStyle? = null,
    fontWeight: FontWeight? = null,
    fontFamily: FontFamily? = null,
    letterSpacing: TextUnit = TextUnit.Unspecified,
    textDecoration: TextDecoration? = null,
    textAlign: TextAlign? = null,
    lineHeight: TextUnit = TextUnit.Unspecified,
    overflow: TextOverflow = TextOverflow.Clip,
    softWrap: Boolean = true,
    maxLines: Int = Int.MAX_VALUE,
    minLines: Int = 1,
    onTextLayout: ((TextLayoutResult) -> Unit)? = null,
    style: TextStyle = LocalTextStyle.current,
    brandName: Boolean = false,
) {
    ComfortText(
        text = remember(text) { AnnotatedString(text) },
        modifier = modifier, color = color, fontSize = fontSize, fontStyle = fontStyle,
        fontWeight = fontWeight, fontFamily = fontFamily, letterSpacing = letterSpacing,
        textDecoration = textDecoration, textAlign = textAlign, lineHeight = lineHeight,
        overflow = overflow, softWrap = softWrap, maxLines = maxLines, minLines = minLines,
        onTextLayout = onTextLayout, style = style, brandName = brandName,
    )
}

@Composable
fun ComfortText(
    text: AnnotatedString,
    modifier: Modifier = Modifier,
    color: Color = Color.Unspecified,
    fontSize: TextUnit = TextUnit.Unspecified,
    fontStyle: FontStyle? = null,
    fontWeight: FontWeight? = null,
    fontFamily: FontFamily? = null,
    letterSpacing: TextUnit = TextUnit.Unspecified,
    textDecoration: TextDecoration? = null,
    textAlign: TextAlign? = null,
    lineHeight: TextUnit = TextUnit.Unspecified,
    overflow: TextOverflow = TextOverflow.Clip,
    softWrap: Boolean = true,
    maxLines: Int = Int.MAX_VALUE,
    minLines: Int = 1,
    inlineContent: Map<String, InlineTextContent> = mapOf(),
    onTextLayout: ((TextLayoutResult) -> Unit)? = null,
    style: TextStyle = LocalTextStyle.current,
    brandName: Boolean = false,
) {
    val effectiveStyle = resolvedStyle(style, fontSize, fontFamily, fontStyle)
    val annotated = remember(text, brandName) { comfortAnnotatedText(text, brandName) }
    MaterialText(
        text = annotated, modifier = modifier, color = color, fontSize = fontSize,
        fontStyle = effectiveStyle.fontStyle, fontWeight = fontWeight,
        fontFamily = effectiveStyle.fontFamily, letterSpacing = letterSpacing,
        textDecoration = textDecoration, textAlign = textAlign, lineHeight = lineHeight,
        overflow = overflow, softWrap = softWrap, maxLines = maxLines, minLines = minLines,
        inlineContent = inlineContent, onTextLayout = onTextLayout ?: {}, style = effectiveStyle,
    )
}
