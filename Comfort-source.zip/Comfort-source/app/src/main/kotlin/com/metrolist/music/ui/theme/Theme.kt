/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.ui.theme

import android.graphics.Bitmap
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.SaverScope
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.unit.dp
import androidx.palette.graphics.Palette
import com.materialkolor.PaletteStyle
import com.materialkolor.dynamiccolor.ColorSpec
import com.materialkolor.rememberDynamicColorScheme
import com.materialkolor.score.Score

/**
 * Comfort's fixed brand seed. Artwork-driven theme preferences still work,
 * but a fresh install starts with the supplied dark-cinematic visual language.
 */
val DefaultThemeColor = Color(0xFFB8B5E8)

object ComfortColors {
    val Lavender = Color(0xFFB8B5E8)
    val LavenderBright = Color(0xFFD6C8FF)
    val Mauve = Color(0xFF8F8CB8)
    val Ink = Color(0xFF080B0F)
    val Charcoal = Color(0xFF11161D)
    val Surface = Color(0xFF171D25)
    val Elevated = Color(0xFF202833)
    val Hairline = Color(0xFF343B47)
    val Pearl = Color(0xFFF6F3EF)
    val Muted = Color(0xFFB3B0B8)
}

private val ComfortLightSurface = Color(0xFFF7F5F2)
private val ComfortLightSurfaceVariant = Color(0xFFEDE9E7)
private val ComfortLightOnSurface = Color(0xFF26252B)
private val ComfortLightOnSurfaceVariant = Color(0xFF706D76)
private val ComfortLightPrimary = Color(0xFF70649A)
private val ComfortLightPrimaryContainer = Color(0xFFE5DFFF)

private val ComfortDarkSurface = ComfortColors.Charcoal
private val ComfortDarkSurfaceVariant = ComfortColors.Elevated
private val ComfortDarkOnSurface = ComfortColors.Pearl
private val ComfortDarkOnSurfaceVariant = ComfortColors.Muted
private val ComfortDarkPrimary = ComfortColors.LavenderBright
private val ComfortDarkPrimaryContainer = Color(0xFF3B3155)

@Composable
fun MetrolistTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    pureBlack: Boolean = false,
    themeColor: Color = DefaultThemeColor,
    content: @Composable () -> Unit,
) {
    // Keep the supplied Comfort palette stable on new devices. The existing
    // artwork-driven and user-selected palette flows still pass themeColor.
    val generatedScheme =
        rememberDynamicColorScheme(
            seedColor = themeColor,
            isDark = darkTheme,
            specVersion = ColorSpec.SpecVersion.SPEC_2025,
            style = PaletteStyle.TonalSpot,
        )
    val baseColorScheme = if (themeColor == DefaultThemeColor) generatedScheme.copy(
            primary = if (darkTheme) ComfortDarkPrimary else ComfortLightPrimary,
            onPrimary = if (darkTheme) Color(0xFF302047) else Color.White,
            primaryContainer =
                if (darkTheme) ComfortDarkPrimaryContainer else ComfortLightPrimaryContainer,
            onPrimaryContainer =
                if (darkTheme) Color(0xFFF0E7FF) else Color(0xFF382B50),
            secondary = if (darkTheme) ComfortColors.Mauve else Color(0xFF6B617B),
            onSecondary = if (darkTheme) ComfortColors.Pearl else Color.White,
            secondaryContainer = if (darkTheme) Color(0xFF342E40) else Color(0xFFE7E0ED),
            onSecondaryContainer = if (darkTheme) Color(0xFFECE4F7) else Color(0xFF352C3E),
            background = if (darkTheme) ComfortDarkSurface else ComfortLightSurface,
            onBackground = if (darkTheme) ComfortDarkOnSurface else ComfortLightOnSurface,
            surface = if (darkTheme) ComfortDarkSurface else ComfortLightSurface,
            onSurface = if (darkTheme) ComfortDarkOnSurface else ComfortLightOnSurface,
            surfaceVariant =
                if (darkTheme) ComfortDarkSurfaceVariant else ComfortLightSurfaceVariant,
            onSurfaceVariant =
                if (darkTheme) ComfortDarkOnSurfaceVariant else ComfortLightOnSurfaceVariant,
            surfaceContainer = if (darkTheme) ComfortColors.Surface else Color(0xFFF2EFEC),
            surfaceContainerLow = if (darkTheme) Color(0xFF131920) else Color(0xFFF8F6F3),
            surfaceContainerHigh = if (darkTheme) ComfortColors.Elevated else Color(0xFFE8E4E1),
            surfaceContainerHighest = if (darkTheme) Color(0xFF29313C) else Color(0xFFE1DDDA),
            inverseSurface = if (darkTheme) ComfortColors.Pearl else ComfortColors.Charcoal,
            inverseOnSurface = if (darkTheme) ComfortColors.Charcoal else ComfortColors.Pearl,
            outline = if (darkTheme) Color(0xFF666B76) else Color(0xFFCFC9C7),
            outlineVariant = if (darkTheme) ComfortColors.Hairline else Color(0xFFE1DCDA),
        ) else generatedScheme

    // Apply pureBlack modification if needed, similar to original logic
    val colorScheme = remember(baseColorScheme, pureBlack, darkTheme) {
        if (darkTheme && pureBlack) {
            baseColorScheme.pureBlack(true)
        } else {
            baseColorScheme
        }
    }

    // Use standard MaterialTheme instead of MaterialExpressiveTheme
    MaterialTheme(
        colorScheme = colorScheme,
        shapes =
            Shapes(
                extraSmall = androidx.compose.foundation.shape.RoundedCornerShape(10.dp),
                small = androidx.compose.foundation.shape.RoundedCornerShape(14.dp),
                medium = androidx.compose.foundation.shape.RoundedCornerShape(18.dp),
                large = androidx.compose.foundation.shape.RoundedCornerShape(24.dp),
                extraLarge = androidx.compose.foundation.shape.RoundedCornerShape(30.dp),
            ),
        typography = com.metrolist.music.ui.typography.ComfortTextStyles.Typography,
        content = content,
    )
}

fun Bitmap.extractThemeColor(): Color = Color(
    Palette.from(this)
        .maximumColorCount(8)
        .generate()
        .rankedColors(1, DefaultThemeColor.toArgb())
        .first()
)

internal fun Palette.rankedColors(
    desiredColorCount: Int,
    fallbackColor: Int,
): List<Int> = Score.score(
    swatches.associate { it.rgb to it.population },
    desiredColorCount,
    fallbackColor,
    true,
)

fun ColorScheme.pureBlack(apply: Boolean) =
    if (apply) copy(
        surface = Color.Black,
        background = Color.Black
    ) else this

val ColorSaver = object : Saver<Color, Int> {
    override fun restore(value: Int): Color = Color(value)
    override fun SaverScope.save(value: Color): Int = value.toArgb()
}
