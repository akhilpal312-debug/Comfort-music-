package com.metrolist.music.ui.theme

import com.metrolist.music.ui.typography.ComfortFontFamilies

// Kept as a source-compatible alias for existing Wrapped typography call sites.
val bbhBartle = ComfortFontFamilies.Music
