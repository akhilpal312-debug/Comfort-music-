package com.metrolist.music.profile

import android.content.Context
import java.io.File

object UsernameStore {
    @Volatile private var instance: UsernameProfiles? = null
    fun get(context: Context): UsernameProfiles = instance ?: synchronized(this) {
        instance ?: UsernameProfiles(File(context.applicationContext.noBackupFilesDir, "comfort_profiles")).also { instance = it }
    }
}
