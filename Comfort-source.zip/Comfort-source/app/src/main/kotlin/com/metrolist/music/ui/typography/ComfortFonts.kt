package com.metrolist.music.ui.typography

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontSynthesis
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.metrolist.music.R

object ComfortFontFamilies {
    val Brand = FontFamily(Font(R.font.comfort_brand_fraktur, FontWeight.Bold))
    val Music = FontFamily(
        Font(R.font.comfort_music_italic_400, FontWeight.Normal, FontStyle.Italic),
        Font(R.font.comfort_music_italic_500, FontWeight.Medium, FontStyle.Italic),
        Font(R.font.comfort_music_italic_600, FontWeight.SemiBold, FontStyle.Italic),
        Font(R.font.comfort_music_italic_700, FontWeight.Bold, FontStyle.Italic),
    )
    val Readable = FontFamily(
        Font(R.font.comfort_readable_400, FontWeight.Normal),
        Font(R.font.comfort_readable_500, FontWeight.Medium),
        Font(R.font.comfort_readable_600, FontWeight.SemiBold),
        Font(R.font.comfort_readable_700, FontWeight.Bold),
    )
    val Devanagari = FontFamily(
        Font(R.font.comfort_devanagari_400, FontWeight.Normal),
        Font(R.font.comfort_devanagari_600, FontWeight.SemiBold),
        Font(R.font.comfort_devanagari_700, FontWeight.Bold),
    )
    val Gurmukhi = FontFamily(
        Font(R.font.comfort_gurmukhi_400, FontWeight.Normal),
        Font(R.font.comfort_gurmukhi_600, FontWeight.SemiBold),
        Font(R.font.comfort_gurmukhi_700, FontWeight.Bold),
    )
}

object ComfortTextStyles {
    val Brand = TextStyle(
        fontFamily = ComfortFontFamilies.Brand, fontWeight = FontWeight.Bold,
        fontStyle = FontStyle.Normal, fontSynthesis = FontSynthesis.None,
        fontSize = 28.sp, lineHeight = 36.sp, letterSpacing = 0.sp,
    )
    val Input = TextStyle(
        fontFamily = ComfortFontFamilies.Readable, fontStyle = FontStyle.Normal,
        fontSynthesis = FontSynthesis.None, fontSize = 16.sp, lineHeight = 24.sp,
    )
    val Typography: Typography = Typography().run {
        fun TextStyle.music(weight: FontWeight = fontWeight ?: FontWeight.Normal) = copy(
            fontFamily = ComfortFontFamilies.Music, fontStyle = FontStyle.Italic,
            fontWeight = weight, fontSynthesis = FontSynthesis.None, letterSpacing = 0.sp,
        )
        fun TextStyle.readable() = copy(
            fontFamily = ComfortFontFamilies.Readable, fontStyle = FontStyle.Normal,
            fontSynthesis = FontSynthesis.None,
        )
        copy(
            displayLarge = displayLarge.music(), displayMedium = displayMedium.music(),
            displaySmall = displaySmall.music(), headlineLarge = headlineLarge.music(FontWeight.SemiBold),
            headlineMedium = headlineMedium.music(FontWeight.SemiBold), headlineSmall = headlineSmall.music(FontWeight.SemiBold),
            titleLarge = titleLarge.music(FontWeight.SemiBold), titleMedium = titleMedium.music(FontWeight.Medium),
            titleSmall = titleSmall.music(FontWeight.Medium), bodyLarge = bodyLarge.music(),
            bodyMedium = bodyMedium.music(), bodySmall = bodySmall.readable(),
            labelLarge = labelLarge.music(FontWeight.Medium), labelMedium = labelMedium.readable(),
            labelSmall = labelSmall.readable(),
        )
    }
}
