package com.metrolist.music.auth
import org.junit.Assert.*
import org.junit.Test
import kotlinx.serialization.json.*
class YouTubeWebSessionTest {
 @Test fun standardAndSecureCookieVariantsAreSupported() {
  for (n in listOf("SAPISID", "__Secure-3PAPISID", "__Secure-1PAPISID")) assertTrue(YouTubeWebSession.hasAuthCookie("$n=test-fixture; SID=test"))
 }
 @Test fun absentOrEmptyAuthCookiesAreNotAuthenticated() {
  for (s in listOf("", "SID=only", "SAPISID=", "SID=SAPISID")) assertFalse(YouTubeWebSession.hasAuthCookie(s))
 }
 @Test fun onlyTheExactSecureMusicOriginCanProvideSessionData() {
  assertTrue(YouTubeWebSession.isMusicOrigin("https://music.youtube.com/"))
  for (s in listOf("http://music.youtube.com", "https://music.youtube.com.attacker.test", "https://accounts.google.com", "https://music.youtube.com:444", "javascript:alert(1)", "bad")) assertFalse(YouTubeWebSession.isMusicOrigin(s))
 }
 @Test fun jsonReturnedByEvaluateJavascriptIsUnwrappedWithoutUnicodeChanges() {
  val obj="""{"visitorData":"fixture","dataSyncId":"id||suffix","name":"अखिल"}"""
  assertEquals("अखिल",YouTubeWebSession.decodeJavascriptResult(Json.encodeToString(obj))!!["name"]!!.jsonPrimitive.content)
  assertEquals("fixture",YouTubeWebSession.decodeJavascriptResult(obj)!!["visitorData"]!!.jsonPrimitive.content)
 }
 @Test fun invalidJavascriptResultsFailClosed() {
  for (s in listOf(null,"null","undefined","\"undefined\"","[]")) assertNull(YouTubeWebSession.decodeJavascriptResult(s))
 }
}
