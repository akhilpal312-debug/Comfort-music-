package com.metrolist.music.auth
import androidx.datastore.preferences.core.mutablePreferencesOf
import com.metrolist.music.constants.AudioFocusEnabledKey
import com.metrolist.music.constants.DynamicThemeKey
import org.junit.Assert.*
import org.junit.Test
class ComfortReleaseDefaultsTest {
 @Test fun firstUpgradeEnablesTheRequestedFeatures() {
  val p=mutablePreferencesOf(DynamicThemeKey to false,AudioFocusEnabledKey to false);applyComfortReleaseDefaults(p)
  assertEquals(true,p[DynamicThemeKey]);assertEquals(true,p[AudioFocusEnabledKey]);assertEquals(true,p[ComfortArtworkAndFocusDefaultsKey])
 }
 @Test fun laterUserChoicesAreNotOverwritten() {
  val p=mutablePreferencesOf(ComfortArtworkAndFocusDefaultsKey to true,DynamicThemeKey to false,AudioFocusEnabledKey to false);applyComfortReleaseDefaults(p)
  assertEquals(false,p[DynamicThemeKey]);assertEquals(false,p[AudioFocusEnabledKey])
 }
}
