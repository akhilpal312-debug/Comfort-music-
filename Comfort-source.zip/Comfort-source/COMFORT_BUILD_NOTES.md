# Comfort Android build notes

This source tree is a targeted UI/branding customization of the upstream Meld Android client at commit `29ea20ba748bc27cfdb9d5a43b21eca48707b5de`.

## Changelog and About changes

- Replaced the Changelog heading with **Comfort — Changelog**.
- Added a verified current-version card using the actual build version.
- Added a concise Comfort introduction and an explicit note that historical release notes come from the upstream release feed.
- Kept real release descriptions and dates from the release feed; only the customized app presentation and obsolete project/support links are adapted.
- Replaced the Changelog GitHub action with a working Instagram action for `@iamakhil_yt` at `https://www.instagram.com/iamakhil_yt/`.
- Adapted upstream Meld/Metrolist wording and the old project/Discord links when displayed inside the Changelog; unrelated provider and legal links are not redirected.
- Removed RD completely from the About page.
- About now shows Comfort, the actual installed version, the supplied application description, the supplied Akhil Pal profile photo, and a working Instagram action.
- Removed visible upstream developer/collaborator cards and repository/community/license cards from About.
- Kept the repository `LICENSE` and source-level GPL-3.0 notices intact.

## Frontend/theme work

- Shared Compose theme uses warm cream surfaces, dark navy text, coral primary accents, soft blue secondary accents, rounded premium surfaces, and dark-mode support.
- Launcher/adaptive icon uses the Comfort music-note logo.
- The new dark player reference is included under `design/`; the existing real player implementation remains intact and was not replaced with a mockup.
- The supplied profile photo and reference assets are bundled in the source archive.

## Reproducible build

1. Install JDK 21, Android SDK platform 37.0, and build-tools 37.0.0.
2. Set `sdk.dir` in `local.properties`.
3. Run:

   ```bash
   ./gradlew :app:assembleIzzyRelease --no-daemon --max-workers=1
   ```

For production distribution, use your own keystore through the existing `release` signing configuration and `STORE_PASSWORD`, `KEY_ALIAS`, and `KEY_PASSWORD` environment variables. The delivered APK is signed with a local Comfort key that is not included in this archive.

## Verification status

- Targeted Kotlin compilation: **passed**.
- Final release compilation and packaging: **passed**.
- APK signature verification: **passed** with APK Signature Scheme v2 and v3.
- Package: `com.meld.app`; version `0.9.2`, versionCode `28`; application label `Comfort`.
- Instagram destination: **implemented as HTTPS URL**.
- RD: **removed**.
- Device/emulator installation test: **not completed**; no Android device or emulator was available.
- Live provider/network playback, login, notifications, lyrics, and background playback: **not fully exercised**.
- Runtime screenshots of Changelog/About: **not captured** because no emulator/device was available.
