# Comfort — global typography redesign

## Outcome and scope

The existing icon-redesign source has been updated with offline Gothic branding, elegant italic music typography and readable script-aware fallbacks. This is an implementation in the real Kotlin/Jetpack Compose application, not a screenshot-only redesign. The existing logo, icon artwork, palette, navigation and music features are preserved.

This pass changes text presentation only. It does not rewrite song metadata, perform mathematical/Fraktur Unicode substitution, alter search matching, or add network font downloads.

## Fonts bundled locally

All five upstream font families are distributed under the SIL Open Font License 1.1. Complete notices are included under `design/comfort-typography/licenses/` and packaged inside the APK under `assets/font_licenses/`.

| Role | Upstream font | Bundled files / weights |
| --- | --- | --- |
| Comfort brand name | UnifrakturCook Bold | `comfort_brand_fraktur.ttf`, 700 |
| Music and intended general text | STIX Two Text Italic | `comfort_music_italic_400.ttf`, `_500.ttf`, `_600.ttf`, `_700.ttf` |
| Small labels and editable controls | Noto Sans | `comfort_readable_400.ttf`, `_500.ttf`, `_600.ttf`, `_700.ttf` |
| Hindi / Devanagari | Noto Sans Devanagari | `comfort_devanagari_400.ttf`, `_600.ttf`, `_700.ttf` |
| Punjabi / Gurmukhi | Noto Sans Gurmukhi | `comfort_gurmukhi_400.ttf`, `_600.ttf`, `_700.ttf` |

These are closest matching real fonts, not an identification of a single exact font behind the supplied Unicode examples. UnifrakturCook provides authentic Gothic/Fraktur lettering; STIX Two Text provides the elegant italic serif character associated with mathematical italic text. Small labels and Indic scripts deliberately stay upright for readability and correct shaping.

The four variable upstream font families were instantiated into static TTFs. Derivative internal family and PostScript names were renamed to Comfort Music Serif, Comfort Readable, Comfort Devanagari and Comfort Gurmukhi. UnifrakturCook is an unmodified font copy. Exact source URLs, upstream checksums, bundled checksums, weights and instancing details are recorded in `design/comfort-typography/font-manifest.json`.

## Reusable implementation

The shared implementation is in `app/src/main/kotlin/com/metrolist/music/ui/typography/`:

- `ComfortFonts.kt`: bundled font families and Material 3 typography tokens.
- `ComfortText.kt`: drop-in text renderer preserving modifiers, line limits, ellipsis, annotations, inline content, layout callbacks, colors and content.
- `ComfortScriptFallback.kt`: UTF-16-safe script runs and font-only spans. Devanagari/Gurmukhi use bundled upright fonts; other scripts use Android's existing system fallback.
- `ComfortTypefaces.kt`: native Canvas lyric exports and per-cluster lyric glow use the same font families.

The shared theme now uses `ComfortTextStyles.Typography`. Existing text callers use the wrapper; text-measurement calls and linked text also receive the same script-aware annotations. Existing legacy font aliases point to the new music family for source compatibility. Old font files are retained as unused legacy resources; no live application Kotlin reference loads the old BBH Bartle TTF.

### Styling rules

- Only app-owned brand displays explicitly opt into Fraktur. The styled substring is the plain word `Comfort`, not an entire sentence. A user song or playlist named Comfort is not automatically branded.
- Music titles, artists, albums, playlists, music cards, queue entries, lyrics and appropriate headings/body/large labels use STIX italic, with real 400/500/600/700 weights.
- Small Material labels/bodySmall and music-family text below 13 sp use upright Noto Sans. Existing monospaced diagnostic/token text stays monospaced.
- Editable search, login, token, rename and other text fields stay upright and readable. Values, input callbacks, cursor behavior and matching are unchanged.
- Hindi and Punjabi display runs use bundled Noto fonts; their original characters, combining marks and joiners remain intact. Other supported scripts and emoji rely on device system fallback.
- XML widget TextViews use local font-family resources, retaining dimensions, IDs, text, colors and actions. Inherited 10 sp card labels and equalizer graph labels explicitly remain upright/readable. Large text uses music italic; tiny text uses readable upright.
- Native Canvas exports choose a readable whole-line script fallback for mixed-script lines; Compose display text uses per-run fallback. A mixed-script Canvas line may therefore be upright rather than partially italic.
- The logo-only Android splash is unchanged. No replacement logo or extra branding image was generated. Android-owned launcher labels, notifications, lock-screen labels, system dialogs and third-party login/provider surfaces keep their supported system typography.

## Coverage and preservation audit

A pre-implementation inventory contains 180 files and 2,239 typography-related occurrences, including model/renderer references that are not independent UI text. The source audit covers all 96 screen source files, all 23 menu files, player components, shared cards/dialogs and widget layouts. `screen-source-coverage.csv` lists every audited UI source and explicitly marks Android runtime testing as not performed.

Coverage includes Home, Search and results/history, Library/local files, favorites/downloads through the existing playlist/library screens, playlists, albums, artists, profile/account/About, Now Playing and mini-player, queue, lyrics/share cards, recognition/history, listening history/statistics, charts/genres, podcast/Spotify surfaces, all settings/integrations, equalizer/wizard, Wrapped, dialogs, context menus and secondary/error/loading interfaces.

The preservation audit compared this source against the preceding icon-redesign source ZIP:

- All 251 drawable/mipmap resources are byte-identical, including the current Comfort logo and launcher artwork.
- All 3 icon-system source files and all 12 editable brand-design assets are byte-identical.
- All 220 checked playback, recognition-service, database, provider/library and ViewModel files are byte-identical.
- All 117 values/translation resource files and all 10 manifest/build/dependency configuration files are byte-identical.
- All 1,849 extracted callback expressions are unchanged after whitespace normalization; this is a source comparison, not a runtime interaction test.
- Six widget layout trees are identical after excluding only the requested fontFamily/textStyle changes (24 TextViews).
- The Wrapped app wordmark now uses the existing app-name resource, `Comfort`, instead of the uppercase/legacy localized wordmark resource. This affects only three brand-rendering layers, not music or user data.

Detailed results are in `source-preservation-audit.json`, `migration-summary.json`, `changed-existing-files.txt` and the font manifest.

## Verification performed

- FontTools validation of all 15 TTF files: expected weights, checksums, static-font tables and sample glyph coverage.
- Indic GSUB/GPOS shaping tables checked, including Hindi conjuncts and Punjabi extended letters.
- Eight typography JVM tests cover unchanged Unicode content, UTF-16 script segmentation, Indic fallback families, preserved links/emphasis, opt-in brand behavior, readable typography tokens and bundled font/license resources.
- Six existing icon-system JVM tests protect the preceding icon pass.
- Chromium specimens use the actual bundled TTF files. Dark/light 1200 px specimens, 360 px compact specimen, 360 px enlarged 130% specimen and a 720 px specimen were individually rendered and visually inspected. Long-title ellipsis, two-line clamping, Latin/Hindi/Punjabi shaping, small labels and readable search input were checked. Intentional ellipsis is not considered an overflow failure.

**The specimen images are not Android app screenshots.** They validate font files and representative constraints, not every actual screen. No emulator, physical device or connected adb target is available. Installation, launch, Android font fallback/loading, actual screen layouts, system font scaling, keyboard behavior, RTL on a device, widget behavior, playback, notification/lock-screen controls and every-button interaction remain unverified at runtime.

## Build and delivery

- `:app:assembleIzzyRelease`: successful, including a final rebuild of the small-label font fixes.
- `:app:testIzzyDebugUnitTest`: 14 selected tests passed (8 typography + 6 icon regression), zero failures/errors.
- Release signed and verified with APK Signature Scheme v2 and v3. 16 KB ZIP alignment verification passed.
- All 15 new bundled TTF payloads match their source checksums inside the APK; all five font license notices match.
- Compiled playlist-widget font references match the final source, including the 12 inherited 10 sp card labels kept upright.
- Package: `com.meld.app`; label: `Comfort`; version: `0.9.2` / code 28; min SDK 26, target SDK 36.
- APK: `Comfort-0.9.2-typography-izzy-release.apk` (30,846,422 bytes).
- APK SHA-256: `8cae6d964e28ecf5d55d76963f37110699519adbdd1480be8b650ddcfa44f973`.
- Certificate SHA-256: `a7054e165da9540e40c43cf7ff4c11672158d1fecbda1e869bf2b7c291e4fb32`.
- The certificate matches the immediately preceding icon-redesign APK. This is intended as an in-place update to that build, but actual installation/data retention were not tested. An older APK signed with a different certificate will not update in place.
- No private signing key is included in the deliverables. Future updates must use the same original signing key.


The source ZIP excludes build outputs, local SDK paths, Gradle caches and private signing keys. Fonts and license notices are included locally. Dependency resolution may still require network access when rebuilding from a fresh Gradle cache; the installed app does not require network access to load these fonts.

## Suggested device acceptance checks

1. Install over the preceding icon APK and confirm existing data is retained.
2. Verify brand wordmarks on About/account/updates/Wrapped without changing the logo.
3. Inspect music rows, mini-player, full player, queue, cards, lyrics and all settings in both themes.
4. Check very long titles at compact/tablet widths and at Android font scales 100%, 130% and 200%.
5. Check mixed English/Hindi/Punjabi, emoji, Arabic/RTL and Japanese with the device's actual fallback fonts.
6. Verify search/rename/login/token editing, copy/paste, TalkBack labels and original search matching.
7. Check word-synchronized lyrics/glow, share-image exports and widget text.
8. Exercise playback, queue, favorites, downloads, notification/lock-screen controls and menu navigation.
